| State          | Capital        | Latitude         | Longitude         | ST | 
|----------------|----------------|------------------|-------------------|----| 
| Alabama        | Montgomery     | 32.3778448300578 | -86.300280684889  | AL | 
| Alaska         | Juneau         | 58.3019435628538 | -134.419720089079 | AK | 
| Arizona        | Phoenix        | 33.448056962118  | -112.097002114648 | AZ | 
| Arkansas       | Little Rock    | 34.74671389912   | -92.2891966155731 | AR | 
| California     | Sacramento     | 38.5766379822497 | -121.493173407028 | CA | 
| Colorado       | Denver         | 39.7393011782883 | -104.984882535635 | CO | 
| Connecticut    | Hartford       | 41.7640478075494 | -72.682265685282  | CT | 
| Delaware       | Dover          | 39.1598182563424 | -75.521440669349  | DE | 
| Florida        | Tallahassee    | 30.4379800379088 | -84.2814103124204 | FL | 
| Georgia        | Atlanta        | 33.7491105069311 | -84.3882728102467 | GA | 
| Hawaii         | Honolulu       | 21.3071891251897 | -157.857644685749 | HI | 
| Idaho          | Boise          | 43.6173976205726 | -116.200071549668 | ID | 
| Illinois       | Springfield    | 39.7992266437577 | -89.6838561293087 | IL | 
| Indiana        | Indianapolis   | 39.7682876590079 | -86.1619162318749 | IN | 
| Iowa           | Des Moines     | 41.591203450586  | -93.6038299676467 | IA | 
| Kansas         | Topeka         | 39.0481868390344 | -95.6781165783569 | KS | 
| Kentucky       | Frankfort      | 38.1868295579102 | -84.8752029177421 | KY | 
| Louisiana      | Baton Rouge    | 30.4561959742174 | -91.1873435440524 | LA | 
| Maine          | Augusta        | 44.3068311917176 | -69.7824740545278 | ME | 
| Maryland       | Annapolis      | 38.9788809750953 | -76.490730353326  | MD | 
| Massachusetts  | Boston         | 42.3585156598684 | -71.0635920009677 | MA | 
| Michigan       | Lansing        | 42.7337559214066 | -84.5554894724477 | MI | 
| Minnesota      | St. Paul       | 44.9544483754758 | -93.1023668129999 | MN | 
| Mississippi    | Jackson        | 32.3038596464079 | -90.1821570985857 | MS | 
| Missouri       | Jefferson City | 38.5792342520804 | -92.1729471612446 | MO | 
| Montana        | Helena         | 46.5844748792441 | -112.017030200267 | MT | 
| Nebraska       | Lincoln        | 40.8080846893224 | -96.6997323196763 | NE | 
| Nevada         | Carson City    | 39.1639658818133 | -119.765996538968 | NV | 
| New Hampshire  | Concord        | 43.2077286653951 | -71.5360412913525 | NH | 
| New Jersey     | Trenton        | 40.2205925416604 | -74.7701082395055 | NJ | 
| New Mexico     | Santa Fe       | 35.682385674315  | -105.939263846866 | NM | 
| New York       | Albany         | 42.6531923942429 | -73.7584566763079 | NY | 
| North Carolina | Raleigh        | 35.7808620976202 | -78.6390536727153 | NC | 
| North Dakota   | Bismarck       | 46.8204800624107 | -100.782425301832 | ND | 
| Ohio           | Columbus       | 39.9611972655304 | -83.000216483074  | OH | 
| Oklahoma       | Oklahoma City  | 35.4930913156566 | -97.5033086417702 | OK | 
| Oregon         | Salem          | 44.9383658965847 | -123.030608818409 | OR | 
| Pennsylvania   | Harrisburg     | 40.2651554758888 | -76.8841110484574 | PA | 
| Rhode Island   | Providence     | 41.8304368543275 | -71.4150694021695 | RI | 
| South Carolina | Columbia       | 34.0006222412432 | -81.033361075349  | SC | 
| South Dakota   | Pierre         | 44.3671499721808 | -100.345546329203 | SD | 
| Tennessee      | Nashville      | 36.1658136639888 | -86.7844011981955 | TN | 
| Texas          | Austin         | 30.2746490151032 | -97.7403787162921 | TX | 
| Utah           | Salt Lake City | 40.7765189566751 | -111.888143519988 | UT | 
| Vermont        | Montpelier     | 44.2619812631813 | -72.5804431413164 | VT | 
| Virginia       | Richmond       | 37.5387725441582 | -77.4334960632491 | VA | 
| Washington     | Olympia        | 47.0362418589047 | -122.904762637417 | WA | 
| West Virginia  | Charleston     | 38.3363786775331 | -81.6126542355569 | WV | 
| Wisconsin      | Madison        | 43.0752429469311 | -89.384196048713  | WI | 
| Wyoming        | Cheyenne       | 41.1407764260928 | -104.820410067003 | WY | 
