| Acceleration | Cylinders | Displacement | Horsepower | Miles_per_Gallon | Name                                 | Origin | Weight_in_lbs | Year         | 
|--------------|-----------|--------------|------------|------------------|--------------------------------------|--------|---------------|--------------| 
| 9            | 8         | 400          | 230        | 16               | pontiac grand prix                   | USA    | 4278          | 94716000000  | 
| 10           | 8         | 455          | 225        | 14               | pontiac catalina                     | USA    | 4425          | 21600000     | 
| 10           | 8         | 455          | 225        | 14               | buick estate wagon (sw)              | USA    | 3086          | 21600000     | 
| 11           | 8         | 455          | 225        | 12               | buick electra 225 custom             | USA    | 4951          | 94716000000  | 
| 9            | 8         | 454          | 220        | 14               | chevrolet impala                     | USA    | 4354          | 21600000     | 
| 8            | 8         | 440          | 215        | 14               | plymouth fury iii                    | USA    | 4312          | 21600000     | 
| 14           | 8         | 360          | 215        | 10               | ford f250                            | USA    | 4615          | 21600000     | 
| 11           | 8         | 440          | 215        | 13               | chrysler new yorker brougham         | USA    | 4735          | 94716000000  | 
| 13           | 8         | 318          | 210        | 11               | dodge d200                           | USA    | 4382          | 21600000     | 
| 11           | 8         | 429          | 208        | 11               | mercury marquis                      | USA    | 4633          | 63093600000  | 
| 15           | 8         | 307          | 200        | 10               | chevy c20                            | USA    | 4376          | 21600000     | 
| 10           | 8         | 429          | 198        | 15               | ford galaxie 500                     | USA    | 4341          | 21600000     | 
| 11           | 8         | 429          | 198        | 12               | mercury marquis brougham             | USA    | 4952          | 94716000000  | 
| 18           | 8         | 304          | 193        | 9                | hi 1200d                             | USA    | 4732          | 21600000     | 
| 8            | 8         | 390          | 190        | 15               | amc ambassador dpl                   | USA    | 3850          | 21600000     | 
| 12           | 8         | 400          | 190        | 13               | chrysler newport royal               | USA    | 4422          | 63093600000  | 
| 12           | 8         | 400          | 190        | 15               | chrysler cordoba                     | USA    | 4325          | 220946400000 | 
| 11           | 8         | 383          | 180        | 12               | dodge monaco (sw)                    | USA    | 4955          | 31557600000  | 
| 12           | 8         | 350          | 180        | 12               | oldsmobile vista cruiser             | USA    | 4499          | 94716000000  | 
| 11           | 8         | 350          | 180        | 11               | oldsmobile omega                     | USA    | 3664          | 94716000000  | 
| 12           | 8         | 350          | 180        | 16               | cadillac seville                     | USA    | 4380          | 189324000000 | 
| 11           | 8         | 400          | 180        | 16               | pontiac grand prix lj                | USA    | 4220          | 220946400000 | 
| 10           | 8         | 383          | 175        |                  | plymouth satellite (sw)              | USA    | 4166          | 21600000     | 
| 11           | 8         | 360          | 175        |                  | amc rebel sst (sw)                   | USA    | 3850          | 21600000     | 
| 11           | 8         | 400          | 175        | 14               | pontiac catalina brougham            | USA    | 4464          | 31557600000  | 
| 12           | 8         | 400          | 175        | 13               | pontiac safari (sw)                  | USA    | 5140          | 31557600000  | 
| 12           | 8         | 400          | 175        | 14               | pontiac catalina                     | USA    | 4385          | 63093600000  | 
| 13           | 8         | 350          | 175        | 13               | buick century 350                    | USA    | 4100          | 94716000000  | 
| 11           | 8         | 360          | 175        | 13               | amc ambassador brougham              | USA    | 3821          | 94716000000  | 
| 10           | 8         | 383          | 170        | 15               | dodge challenger se                  | USA    | 3563          | 21600000     | 
| 12           | 8         | 400          | 170        | 13               | ford country squire (sw)             | USA    | 4746          | 31557600000  | 
| 13           | 8         | 360          | 170        | 13               | plymouth custom suburb               | USA    | 4654          | 94716000000  | 
| 11           | 8         | 400          | 170        | 16               | pontiac catalina                     | USA    | 4668          | 157788000000 | 
| 11           | 8         | 350          | 170        | 15               | chevrolet monte carlo landau         | USA    | 4165          | 220946400000 | 
| 12           | 8         | 400          | 167        | 12               | ford country                         | USA    | 4906          | 94716000000  | 
| 11           | 8         | 350          | 165        | 15               | buick skylark 320                    | USA    | 3693          | 21600000     | 
| 11           | 8         | 350          | 165        |                  | chevrolet chevelle concours (sw)     | USA    | 4142          | 21600000     | 
| 12           | 8         | 350          | 165        | 14               | chevrolet impala                     | USA    | 4209          | 31557600000  | 
| 12           | 8         | 350          | 165        | 13               | chevrolet impala                     | USA    | 4274          | 63093600000  | 
| 13           | 6         | 231          | 165        | 17               | buick regal sport coupe (turbo)      | USA    | 3445          | 252482400000 | 
| 8            | 8         | 340          | 160        | 14               | plymouth 'cuda 340                   | USA    | 3609          | 21600000     | 
| 13           | 8         | 350          | 160        | 12               | oldsmobile delta 88 royale           | USA    | 4456          | 63093600000  | 
| 13           | 8         | 351          | 158        | 13               | ford ltd                             | USA    | 4363          | 94716000000  | 
| 13           | 8         | 350          | 155        | 13               | buick lesabre custom                 | USA    | 4502          | 63093600000  | 
| 14           | 8         | 350          | 155        | 16               | buick estate wagon (sw)              | USA    | 4360          | 284018400000 | 
| 11           | 8         | 351          | 153        |                  | ford torino (sw)                     | USA    | 4034          | 21600000     | 
| 13           | 8         | 351          | 153        | 14               | ford galaxie 500                     | USA    | 4154          | 31557600000  | 
| 13           | 8         | 351          | 153        | 14               | ford galaxie 500                     | USA    | 4129          | 63093600000  | 
| 12           | 8         | 351          | 152        | 14               | ford gran torino                     | USA    | 4215          | 189324000000 | 
| 11           | 8         | 318          | 150        | 18               | plymouth satellite                   | USA    | 3436          | 21600000     | 
| 12           | 8         | 304          | 150        | 16               | amc rebel sst                        | USA    | 3433          | 21600000     | 
| 9            | 8         | 400          | 150        | 15               | chevrolet monte carlo                | USA    | 3761          | 21600000     | 
| 13           | 8         | 318          | 150        | 14               | plymouth fury iii                    | USA    | 4096          | 31557600000  | 
| 13           | 8         | 318          | 150        | 15               | plymouth fury iii                    | USA    | 4135          | 63093600000  | 
| 11           | 8         | 304          | 150        | 17               | amc ambassador sst                   | USA    | 3672          | 63093600000  | 
| 12           | 8         | 304          | 150        | 15               | amc matador (sw)                     | USA    | 3892          | 63093600000  | 
| 14           | 8         | 318          | 150        | 14               | plymouth satellite custom (sw)       | USA    | 4077          | 63093600000  | 
| 11           | 8         | 304          | 150        | 14               | amc matador                          | USA    | 3672          | 94716000000  | 
| 12           | 8         | 318          | 150        | 15               | dodge coronet custom                 | USA    | 3777          | 94716000000  | 
| 12           | 8         | 400          | 150        | 13               | chevrolet caprice classic            | USA    | 4464          | 94716000000  | 
| 14           | 8         | 318          | 150        | 14               | plymouth fury gran sedan             | USA    | 4237          | 94716000000  | 
| 14           | 8         | 400          | 150        | 11               | chevrolet impala                     | USA    | 4997          | 94716000000  | 
| 11           | 8         | 318          | 150        | 15               | dodge dart custom                    | USA    | 3399          | 94716000000  | 
| 14           | 8         | 350          | 150        | 13               | buick century luxus (sw)             | USA    | 4699          | 126252000000 | 
| 13           | 8         | 318          | 150        | 14               | dodge coronet custom (sw)            | USA    | 4457          | 126252000000 | 
| 15           | 8         | 304          | 150        | 14               | amc matador (sw)                     | USA    | 4257          | 126252000000 | 
| 14           | 8         | 318          | 150        | 16               | plymouth grand fury                  | USA    | 4498          | 157788000000 | 
| 13           | 8         | 318          | 150        | 16               | dodge coronet brougham               | USA    | 4190          | 189324000000 | 
| 13           | 8         | 318          | 150        | 13               | plymouth volare premier v8           | USA    | 3940          | 189324000000 | 
| 14           | 8         | 318          | 150        | 13               | dodge d100                           | USA    | 3755          | 189324000000 | 
| 13           | 8         | 360          | 150        | 18               | chrysler lebaron town @ country (sw) | USA    | 3940          | 284018400000 | 
| 14           | 8         | 351          | 149        | 16               | ford thunderbird                     | USA    | 4335          | 220946400000 | 
| 13           | 8         | 351          | 148        | 14               | ford ltd                             | USA    | 4657          | 157788000000 | 
| 13           | 8         | 350          | 145        | 13               | chevrolet malibu                     | USA    | 3988          | 94716000000  | 
| 13           | 8         | 350          | 145        | 15               | chevrolet monte carlo s              | USA    | 4082          | 94716000000  | 
| 14           | 8         | 350          | 145        | 15               | chevrolet bel air                    | USA    | 4440          | 157788000000 | 
| 12           | 8         | 350          | 145        | 13               | chevy c10                            | USA    | 4055          | 189324000000 | 
| 12           | 8         | 305          | 145        | 17               | chevrolet caprice classic            | USA    | 3880          | 220946400000 | 
| 13           | 8         | 318          | 145        | 15               | dodge monaco brougham                | USA    | 4140          | 220946400000 | 
| 13           | 8         | 305          | 145        | 19               | chevrolet monte carlo landau         | USA    | 3425          | 252482400000 | 
| 14           | 8         | 351          | 142        | 15               | ford country squire (sw)             | USA    | 4054          | 284018400000 | 
| 10           | 8         | 302          | 140        | 17               | ford torino                          | USA    | 3449          | 21600000     | 
| 8            | 8         | 302          | 140        |                  | ford mustang boss 302                | USA    | 3353          | 21600000     | 
| 16           | 8         | 302          | 140        | 13               | ford gran torino (sw)                | USA    | 4294          | 63093600000  | 
| 14           | 8         | 302          | 140        | 16               | ford gran torino                     | USA    | 4141          | 126252000000 | 
| 16           | 8         | 302          | 140        | 14               | ford gran torino (sw)                | USA    | 4638          | 126252000000 | 
| 13           | 8         | 305          | 140        | 17               | chevrolet chevelle malibu classic    | USA    | 4215          | 189324000000 | 
| 13           | 8         | 318          | 140        | 19               | dodge diplomat                       | USA    | 3735          | 252482400000 | 
| 13           | 8         | 318          | 140        | 17               | dodge magnum xe                      | USA    | 4080          | 252482400000 | 
| 12           | 8         | 302          | 139        | 20               | mercury monarch ghia                 | USA    | 3570          | 252482400000 | 
| 11           | 8         | 302          | 139        | 18               | ford futura                          | USA    | 3205          | 252482400000 | 
| 13           | 8         | 351          | 138        | 16               | mercury grand marquis                | USA    | 3955          | 284018400000 | 
| 14           | 8         | 302          | 137        | 14               | ford gran torino                     | USA    | 4042          | 94716000000  | 
| 15           | 8         | 318          | 135        | 18               | dodge st. regis                      | USA    | 3830          | 284018400000 | 
| 15           | 6         | 163          | 133        | 16               | peugeot 604sl                        | Europe | 3410          | 252482400000 | 
| 11           | 6         | 168          | 132        | 32               | datsun 280-zx                        | Japan  | 2910          | 315554400000 | 
| 12           | 8         | 307          | 130        | 18               | chevrolet chevelle malibu            | USA    | 3504          | 21600000     | 
| 14           | 8         | 307          | 130        | 13               | chevrolet chevelle concours (sw)     | USA    | 4098          | 63093600000  | 
| 15           | 8         | 302          | 130        | 13               | ford f108                            | USA    | 3870          | 189324000000 | 
| 14           | 8         | 302          | 130        | 15               | mercury cougar brougham              | USA    | 4295          | 220946400000 | 
| 15           | 8         | 305          | 130        | 17               | chevrolet caprice classic            | USA    | 3840          | 284018400000 | 
| 12           | 8         | 302          | 129        | 13               | ford mustang ii                      | USA    | 3169          | 157788000000 | 
| 13           | 8         | 302          | 129        | 17               | ford ltd landau                      | USA    | 3725          | 284018400000 | 
| 13           | 6         | 163          | 125        | 17               | volvo 264gl                          | Europe | 3140          | 252482400000 | 
| 15           | 8         | 267          | 125        | 19               | chevrolet malibu classic (sw)        | USA    | 3605          | 284018400000 | 
| 17           | 8         | 350          | 125        | 23               | cadillac eldorado                    | USA    | 3900          | 284018400000 | 
| 13           | 6         | 156          | 122        | 20               | toyota mark ii                       | Japan  | 2807          | 94716000000  | 
| 13           | 8         | 304          | 120        | 15               | amc matador                          | USA    | 3962          | 189324000000 | 
| 16           | 6         | 168          | 120        | 16               | mercedes-benz 280s                   | Europe | 3820          | 189324000000 | 
| 15           | 6         | 258          | 120        | 18               | amc concord d/l                      | USA    | 3410          | 252482400000 | 
| 13           | 6         | 146          | 120        | 24               | datsun 810 maxima                    | Japan  | 2930          | 378712800000 | 
| 12           | 6         | 168          | 116        | 25               | toyota cressida                      | Japan  | 2900          | 378712800000 | 
| 17           | 4         | 133          | 115        |                  | citroen ds-21 pallas                 | Europe | 3090          | 21600000     | 
| 13           | 4         | 121          | 115        | 25               | saab 99le                            | Europe | 2671          | 157788000000 | 
| 15           | 4         | 121          | 115        | 21               | saab 99gle                           | Europe | 2795          | 252482400000 | 
| 15           | 6         | 231          | 115        | 21               | pontiac lemans v6                    | USA    | 3245          | 284018400000 | 
| 11           | 6         | 173          | 115        | 28               | chevrolet citation                   | USA    | 2595          | 284018400000 | 
| 12           | 6         | 173          | 115        | 26               | oldsmobile omega brougham            | USA    | 2700          | 284018400000 | 
| 12           | 4         | 121          | 113        | 26               | bmw 2002                             | Europe | 2234          | 21600000     | 
| 14           | 4         | 121          | 112        | 18               | volvo 145e (sw)                      | Europe | 2933          | 63093600000  | 
| 15           | 4         | 121          | 112        | 19               | volvo 144ea                          | Europe | 2868          | 94716000000  | 
| 14           | 6         | 232          | 112        | 22               | ford granada l                       | USA    | 2835          | 378712800000 | 
| 13           | 6         | 258          | 110        | 18               | amc hornet sportabout (sw)           | USA    | 2962          | 31557600000  | 
| 14           | 4         | 121          | 110        | 24               | saab 99le                            | Europe | 2660          | 94716000000  | 
| 18           | 6         | 258          | 110        | 16               | amc matador                          | USA    | 3632          | 126252000000 | 
| 21           | 6         | 231          | 110        | 17               | buick century                        | USA    | 3907          | 157788000000 | 
| 19           | 6         | 258          | 110        | 15               | amc matador                          | USA    | 3730          | 157788000000 | 
| 15           | 6         | 231          | 110        | 21               | buick skyhawk                        | USA    | 3039          | 157788000000 | 
| 13           | 8         | 262          | 110        | 20               | chevrolet monza 2+2                  | USA    | 3221          | 157788000000 | 
| 16           | 6         | 250          | 110        | 18               | pontiac ventura sj                   | USA    | 3645          | 189324000000 | 
| 19           | 8         | 260          | 110        | 17               | oldsmobile cutlass supreme           | USA    | 4060          | 220946400000 | 
| 16           | 6         | 250          | 110        | 17               | chevrolet concours                   | USA    | 3520          | 220946400000 | 
| 12           | 4         | 121          | 110        | 21               | bmw 320i                             | Europe | 2600          | 220946400000 | 
| 13           | 3         | 80           | 110        | 21               | mazda rx-4                           | Japan  | 2720          | 220946400000 | 
| 15           | 8         | 260          | 110        | 19               | oldsmobile cutlass salon brougham    | USA    | 3365          | 252482400000 | 
| 18           | 6         | 225          | 110        | 18               | dodge aspen                          | USA    | 3620          | 252482400000 | 
| 16           | 6         | 225          | 110        | 20               | dodge aspen 6                        | USA    | 3360          | 284018400000 | 
| 12           | 6         | 173          | 110        | 23               | chevrolet citation                   | USA    | 2725          | 378712800000 | 
| 15           | 4         | 121          | 110        |                  | saab 900s                            | Europe | 2800          | 378712800000 | 
| 15           | 6         | 231          | 110        | 22               | buick century                        | USA    | 3415          | 378712800000 | 
| 16           | 6         | 181          | 110        | 25               | buick century limited                | USA    | 2945          | 378712800000 | 
| 15           | 6         | 156          | 108        | 19               | toyota mark ii                       | Japan  | 2930          | 189324000000 | 
| 14           | 6         | 155          | 107        | 21               | mercury capri v6                     | USA    | 2472          | 94716000000  | 
| 15           | 6         | 225          | 105        | 16               | plymouth satellite custom            | USA    | 3439          | 31557600000  | 
| 16           | 6         | 225          | 105        | 18               | plymouth valiant                     | USA    | 3121          | 94716000000  | 
| 16           | 6         | 225          | 105        | 18               | plymouth satellite sebring           | USA    | 3613          | 126252000000 | 
| 16           | 6         | 250          | 105        | 18               | chevrolet nova                       | USA    | 3459          | 157788000000 | 
| 18           | 6         | 250          | 105        | 16               | chevroelt chevelle malibu            | USA    | 3897          | 157788000000 | 
| 14           | 6         | 250          | 105        | 22               | chevrolet nova                       | USA    | 3353          | 189324000000 | 
| 16           | 6         | 231          | 105        | 20               | buick skylark                        | USA    | 3425          | 220946400000 | 
| 19           | 6         | 231          | 105        | 19               | pontiac phoenix lj                   | USA    | 3535          | 252482400000 | 
| 15           | 6         | 231          | 105        | 20               | buick century special                | USA    | 3380          | 252482400000 | 
| 16           | 4         | 156          | 105        | 23               | plymouth sapporo                     | USA    | 2745          | 252482400000 | 
| 14           | 4         | 156          | 105        | 27               | dodge colt                           | USA    | 2800          | 315554400000 | 
| 19           | 8         | 350          | 105        | 26               | oldsmobile cutlass ls                | USA    | 3725          | 378712800000 | 
| 15           | 5         | 131          | 103        | 20               | audi 5000                            | Europe | 2830          | 252482400000 | 
| 15           | 4         | 130          | 102        | 20               | volvo 245                            | Europe | 3150          | 189324000000 | 
| 13           | 6         | 232          | 100        | 19               | amc gremlin                          | USA    | 2634          | 31557600000  | 
| 15           | 6         | 250          | 100        | 17               | chevrolet chevelle malibu            | USA    | 3329          | 31557600000  | 
| 15           | 6         | 232          | 100        | 18               | amc matador                          | USA    | 3288          | 31557600000  | 
| 15           | 6         | 250          | 100        | 19               | pontiac firebird                     | USA    | 3282          | 31557600000  | 
| 18           | 6         | 250          | 100        | 16               | chevrolet nova custom                | USA    | 3278          | 94716000000  | 
| 16           | 6         | 232          | 100        | 18               | amc hornet                           | USA    | 2945          | 94716000000  | 
| 15           | 6         | 232          | 100        | 18               | amc gremlin                          | USA    | 2789          | 94716000000  | 
| 16           | 6         | 232          | 100        | 19               | amc hornet                           | USA    | 2901          | 126252000000 | 
| 17           | 6         | 250          | 100        | 15               | chevrolet nova                       | USA    | 3336          | 126252000000 | 
| 17           | 6         | 250          | 100        | 16               | chevrolet chevelle malibu classic    | USA    | 3781          | 126252000000 | 
| 16           | 6         | 232          | 100        | 20               | amc gremlin                          | USA    | 2914          | 157788000000 | 
| 15           | 6         | 225          | 100        | 22               | plymouth valiant                     | USA    | 3233          | 189324000000 | 
| 17           | 6         | 225          | 100        | 20               | dodge aspen se                       | USA    | 3651          | 189324000000 | 
| 17           | 6         | 225          | 100        | 19               | plymouth volare custom               | USA    | 3630          | 220946400000 | 
| 17           | 6         | 225          | 100        | 20               | plymouth volare                      | USA    | 3430          | 252482400000 | 
| 12           | 3         | 70           | 100        | 23               | mazda rx-7 gs                        | Japan  | 2420          | 315554400000 | 
| 14           | 4         | 119          | 100        | 32               | datsun 200sx                         | Japan  | 2615          | 378712800000 | 
| 14           | 4         | 121          | 98         | 22               | volvo 244dl                          | Europe | 2945          | 157788000000 | 
| 19           | 6         | 250          | 98         | 18               | ford granada                         | USA    | 3525          | 220946400000 | 
| 15           | 6         | 199          | 97         | 18               | amc hornet                           | USA    | 2774          | 21600000     | 
| 13           | 3         | 70           | 97         | 19               | mazda rx2 coupe                      | Japan  | 2330          | 63093600000  | 
| 14           | 4         | 120          | 97         | 23               | toyouta corona mark ii (sw)          | Japan  | 2506          | 63093600000  | 
| 15           | 4         | 120          | 97         | 24               | honda civic                          | Japan  | 2489          | 126252000000 | 
| 17           | 4         | 119          | 97         | 24               | datsun 710                           | Japan  | 2545          | 157788000000 | 
| 14           | 6         | 171          | 97         | 18               | ford pinto                           | USA    | 2984          | 157788000000 | 
| 14           | 6         | 146          | 97         | 22               | datsun 810                           | Japan  | 2815          | 220946400000 | 
| 14           | 4         | 119          | 97         | 27               | datsun 510                           | Japan  | 2300          | 252482400000 | 
| 14           | 4         | 119          | 97         | 23               | datsun 200-sx                        | Japan  | 2405          | 252482400000 | 
| 13           | 4         | 134          | 96         | 24               | toyota corona                        | Japan  | 2702          | 157788000000 | 
| 15           | 4         | 122          | 96         | 25               | plymouth arrow gs                    | USA    | 2300          | 220946400000 | 
| 13           | 4         | 144          | 96         | 32               | toyota celica gt                     | Japan  | 2665          | 378712800000 | 
| 15           | 4         | 113          | 95         | 24               | toyota corona mark ii                | Japan  | 2372          | 21600000     | 
| 15           | 6         | 198          | 95         | 22               | plymouth duster                      | USA    | 2833          | 21600000     | 
| 17           | 4         | 104          | 95         | 25               | saab 99e                             | Europe | 2375          | 21600000     | 
| 14           | 4         | 113          | 95         | 25               | toyota corona                        | Japan  | 2228          | 31557600000  | 
| 15           | 4         | 113          | 95         | 24               | toyota corona hardtop                | Japan  | 2278          | 63093600000  | 
| 16           | 6         | 198          | 95         | 23               | plymouth duster                      | USA    | 2904          | 94716000000  | 
| 16           | 6         | 198          | 95         | 20               | plymouth duster                      | USA    | 3102          | 126252000000 | 
| 16           | 6         | 225          | 95         | 19               | plymouth valiant custom              | USA    | 3264          | 157788000000 | 
| 19           | 6         | 225          | 95         | 18               | plymouth fury                        | USA    | 3785          | 157788000000 | 
| 15           | 4         | 115          | 95         | 23               | audi 100ls                           | Europe | 2694          | 157788000000 | 
| 17           | 6         | 258          | 95         | 17               | amc pacer d/l                        | USA    | 3193          | 189324000000 | 
| 18           | 6         | 200          | 95         | 20               | chevrolet malibu                     | USA    | 3155          | 252482400000 | 
| 14           | 4         | 134          | 95         | 27               | toyota corona                        | Japan  | 2560          | 252482400000 | 
| 14           | 4         | 134          | 95         | 21               | toyota celica gt liftback            | Japan  | 2515          | 252482400000 | 
| 16           | 4         | 108          | 94         | 22               | datsun 610                           | Japan  | 2379          | 94716000000  | 
| 15           | 4         | 108          | 93         | 26               | subaru                               | Japan  | 2391          | 126252000000 | 
| 17           | 4         | 97           | 92         | 28               | datsun 510 (sw)                      | Japan  | 2288          | 63093600000  | 
| 14           | 4         | 140          | 92         | 25               | capri ii                             | USA    | 2572          | 189324000000 | 
| 15           | 4         | 119          | 92         | 37               | datsun 510 hatchback                 | Japan  | 2434          | 315554400000 | 
| 14           | 4         | 156          | 92         | 25               | dodge aries wagon (sw)               | USA    | 2620          | 378712800000 | 
| 16           | 4         | 140          | 92         | 24               | ford fairmont futura                 | USA    | 2865          | 378712800000 | 
| 14           | 4         | 156          | 92         | 26               | chrysler lebaron medallion           | USA    | 2585          | 378712800000 | 
| 14           | 4         | 114          | 91         | 20               | audi 100ls                           | Europe | 2582          | 94716000000  | 
| 14           | 4         | 107          | 90         | 24               | audi 100 ls                          | Europe | 2430          | 21600000     | 
| 15           | 6         | 199          | 90         | 21               | amc gremlin                          | USA    | 2648          | 21600000     | 
| 15           | 4         | 140          | 90         | 28               | chevrolet vega 2300                  | USA    | 2264          | 31557600000  | 
| 14           | 4         | 116          | 90         | 28               | opel 1900                            | Europe | 2123          | 31557600000  | 
| 19           | 4         | 140          | 90         | 20               | chevrolet vega                       | USA    | 2408          | 63093600000  | 
| 13           | 3         | 70           | 90         | 18               | maxda rx3                            | Japan  | 2124          | 94716000000  | 
| 15           | 4         | 98           | 90         | 26               | fiat 124 sport coupe                 | Europe | 2265          | 94716000000  | 
| 17           | 6         | 232          | 90         | 19               | amc pacer                            | USA    | 3211          | 157788000000 | 
| 17           | 6         | 232          | 90         | 22               | amc hornet                           | USA    | 3085          | 189324000000 | 
| 17           | 6         | 232          | 90         | 19               | amc concord                          | USA    | 3210          | 252482400000 | 
| 18           | 6         | 232          | 90         | 20               | amc concord dl 6                     | USA    | 3265          | 284018400000 | 
| 22           | 8         | 260          | 90         | 23               | oldsmobile cutlass salon brougham    | USA    | 3420          | 284018400000 | 
| 16           | 4         | 151          | 90         | 28               | buick skylark limited                | USA    | 2670          | 284018400000 | 
| 13           | 4         | 151          | 90         | 33               | pontiac phoenix                      | USA    | 2556          | 284018400000 | 
| 16           | 4         | 151          | 90         | 28               | chevrolet citation                   | USA    | 2678          | 315554400000 | 
| 20           | 4         | 151          | 90         | 24               | amc concord                          | USA    | 3003          | 315554400000 | 
| 18           | 6         | 225          | 90         | 19               | dodge aspen                          | USA    | 3381          | 315554400000 | 
| 15           | 4         | 134          | 90         | 29               | toyota corona liftback               | Japan  | 2711          | 315554400000 | 
| 18           | 4         | 151          | 90         | 27               | pontiac phoenix                      | USA    | 2735          | 378712800000 | 
| 17           | 4         | 151          | 90         | 27               | chevrolet camaro                     | USA    | 2950          | 378712800000 | 
| 15           | 4         | 140          | 89         | 25               | ford mustang ii 2+2                  | USA    | 2755          | 220946400000 | 
| 14           | 4         | 97           | 88         | 27               | datsun pl510                         | Japan  | 2130          | 21600000     | 
| 14           | 4         | 97           | 88         | 27               | datsun pl510                         | Japan  | 2130          | 31557600000  | 
| 15           | 6         | 250          | 88         | 19               | ford torino 500                      | USA    | 3302          | 31557600000  | 
| 14           | 6         | 250          | 88         | 18               | ford mustang                         | USA    | 3139          | 31557600000  | 
| 16           | 4         | 97           | 88         | 27               | toyota corolla 1600 (sw)             | Japan  | 2100          | 63093600000  | 
| 16           | 6         | 250          | 88         | 18               | ford maverick                        | USA    | 3021          | 94716000000  | 
| 19           | 4         | 97           | 88         | 20               | toyota carina                        | Japan  | 2279          | 94716000000  | 
| 17           | 4         | 120          | 88         | 23               | peugeot 504                          | Europe | 2957          | 157788000000 | 
| 21           | 4         | 120          | 88         | 19               | peugeot 504                          | Europe | 3270          | 189324000000 | 
| 16           | 4         | 151          | 88         | 24               | pontiac sunbird coupe                | USA    | 2740          | 220946400000 | 
| 15           | 4         | 140          | 88         | 25               | ford fairmont (man)                  | USA    | 2720          | 252482400000 | 
| 17           | 4         | 140          | 88         | 22               | ford fairmont 4                      | USA    | 2890          | 284018400000 | 
| 18           | 4         | 140          | 88         | 26               | ford fairmont                        | USA    | 2870          | 315554400000 | 
| 15           | 4         | 122          | 88         | 35               | triumph tr7 coupe                    | Europe | 2500          | 315554400000 | 
| 17           | 6         | 200          | 88         | 20               | ford granada gl                      | USA    | 3060          | 378712800000 | 
| 19           | 4         | 112          | 88         | 28               | chevrolet cavalier                   | USA    | 2605          | 378712800000 | 
| 18           | 4         | 112          | 88         | 27               | chevrolet cavalier wagon             | USA    | 2640          | 378712800000 | 
| 18           | 4         | 112          | 88         | 34               | chevrolet cavalier 2-door            | USA    | 2395          | 378712800000 | 
| 14           | 4         | 120          | 88         | 36               | nissan stanza xe                     | Japan  | 2160          | 378712800000 | 
| 17           | 4         | 110          | 87         | 25               | peugeot 504                          | Europe | 2672          | 21600000     | 
| 19           | 4         | 120          | 87         | 21               | peugeot 504 (sw)                     | Europe | 2979          | 63093600000  | 
| 14           | 4         | 122          | 86         | 23               | mercury capri 2000                   | USA    | 2220          | 31557600000  | 
| 16           | 4         | 122          | 86         | 21               | ford pinto runabout                  | USA    | 2226          | 63093600000  | 
| 16           | 4         | 122          | 86         | 22               | ford pinto (sw)                      | USA    | 2395          | 63093600000  | 
| 15           | 4         | 107          | 86         | 28               | fiat 131                             | Europe | 2464          | 189324000000 | 
| 15           | 4         | 140          | 86         | 27               | ford mustang gl                      | USA    | 2790          | 378712800000 | 
| 16           | 6         | 200          | 85         | 21               | ford maverick                        | USA    | 2587          | 21600000     | 
| 18           | 4         | 122          | 85         | 19               | ford pinto                           | USA    | 2310          | 94716000000  | 
| 15           | 6         | 200          | 85         | 20               | ford fairmont (auto)                 | USA    | 2965          | 252482400000 | 
| 16           | 6         | 200          | 85         | 20               | mercury zephyr                       | USA    | 3070          | 252482400000 | 
| 17           | 4         | 151          | 85         | 23               | oldsmobile starfire sx               | USA    | 2855          | 252482400000 | 
| 18           | 6         | 200          | 85         | 19               | mercury zephyr 6                     | USA    | 2990          | 284018400000 | 
| 16           | 6         | 225          | 85         | 17               | chrysler lebaron salon               | USA    | 3465          | 378712800000 | 
| 16           | 4         | 112          | 85         | 31               | pontiac j2000 se hatchback           | USA    | 2575          | 378712800000 | 
| 17           | 6         | 262          | 85         | 38               | oldsmobile cutlass ciera (diesel)    | USA    | 3015          | 378712800000 | 
| 15           | 4         | 135          | 84         | 27               | plymouth reliant                     | USA    | 2490          | 378712800000 | 
| 16           | 4         | 151          | 84         | 26               | buick skylark                        | USA    | 2635          | 378712800000 | 
| 12           | 4         | 135          | 84         | 30               | plymouth reliant                     | USA    | 2385          | 378712800000 | 
| 16           | 4         | 135          | 84         | 29               | dodge aries se                       | USA    | 2525          | 378712800000 | 
| 13           | 4         | 135          | 84         | 36               | dodge charger 2.2                    | USA    | 2370          | 378712800000 | 
| 11           | 4         | 135          | 84         | 32               | dodge rampage                        | USA    | 2295          | 378712800000 | 
| 16           | 4         | 98           | 83         | 29               | audi fox                             | Europe | 2219          | 126252000000 | 
| 17           | 4         | 140          | 83         | 23               | ford pinto                           | USA    | 2639          | 157788000000 | 
| 15           | 4         | 101          | 83         | 27               | renault 12tl                         | Europe | 2202          | 189324000000 | 
| 15           | 4         | 98           | 83         | 33               | dodge colt m/m                       | USA    | 2075          | 220946400000 | 
| 19           | 4         | 119          | 82         | 31               | chevy s-10                           | USA    | 2720          | 378712800000 | 
| 16           | 4         | 116          | 81         | 25               | opel 1900                            | Europe | 2220          | 189324000000 | 
| 17           | 6         | 200          | 81         | 24               | ford maverick                        | USA    | 3012          | 189324000000 | 
| 17           | 4         | 97           | 80         | 25               | dodge colt hardtop                   | USA    | 2126          | 63093600000  | 
| 15           | 4         | 98           | 80         | 28               | dodge colt (sw)                      | USA    | 2164          | 63093600000  | 
| 16           | 4         | 122          | 80         | 26               | ford pinto                           | USA    | 2451          | 126252000000 | 
| 14           | 4         | 111          | 80         | 30               | buick opel isuzu deluxe              | USA    | 2155          | 220946400000 | 
| 14           | 4         | 98           | 80         | 35               | dodge colt hatchback custom          | USA    | 1915          | 284018400000 | 
| 15           | 4         | 121          | 80         | 27               | amc spirit dl                        | USA    | 2670          | 284018400000 | 
| 20           | 4         | 141          | 80         | 28               | peugeot 505s turbo diesel            | Europe | 3230          | 378712800000 | 
| 17           | 4         | 98           | 79         | 26               | dodge colt                           | USA    | 2255          | 189324000000 | 
| 18           | 4         | 120          | 79         | 28               | ford ranger                          | USA    | 2625          | 378712800000 | 
| 14           | 4         | 97           | 78         | 26               | opel manta                           | Europe | 2300          | 126252000000 | 
| 18           | 4         | 140          | 78         | 23               | pontiac astro                        | USA    | 2592          | 157788000000 | 
| 21           | 6         | 250          | 78         | 18               | ford granada ghia                    | USA    | 3574          | 189324000000 | 
| 14           | 4         | 97           | 78         | 29               | volkswagen rabbit custom             | Europe | 1940          | 220946400000 | 
| 14           | 4         | 97           | 78         | 30               | volkswagen dasher                    | Europe | 2190          | 220946400000 | 
| 15           | 4         | 97           | 78         | 34               | audi 4000                            | Europe | 2188          | 315554400000 | 
| 20           | 5         | 183          | 77         | 25               | mercedes benz 300d                   | Europe | 3530          | 284018400000 | 
| 14           | 4         | 88           | 76         | 30               | fiat 124b                            | Europe | 2065          | 31557600000  | 
| 18           | 4         | 121          | 76         | 22               | volkswagen 411 (sw)                  | Europe | 2511          | 63093600000  | 
| 14           | 4         | 98           | 76         | 41               | vw rabbit                            | Europe | 2144          | 315554400000 | 
| 19           | 6         | 145          | 76         | 30               | volvo diesel                         | Europe | 3160          | 378712800000 | 
| 15           | 4         | 116          | 75         | 24               | opel manta                           | Europe | 2158          | 94716000000  | 
| 17           | 4         | 140          | 75         | 25               | chevrolet vega                       | USA    | 2542          | 126252000000 | 
| 14           | 4         | 90           | 75         | 28               | dodge colt                           | USA    | 2125          | 126252000000 | 
| 15           | 4         | 90           | 75         | 24               | fiat 128                             | Europe | 2108          | 126252000000 | 
| 14           | 4         | 116          | 75         | 26               | fiat 124 tc                          | Europe | 2246          | 126252000000 | 
| 16           | 4         | 97           | 75         | 29               | toyota corolla                       | Japan  | 2171          | 157788000000 | 
| 16           | 4         | 97           | 75         | 28               | toyota corolla                       | Japan  | 2155          | 189324000000 | 
| 18           | 4         | 97           | 75         | 26               | toyota corolla liftback              | Japan  | 2265          | 220946400000 | 
| 14           | 4         | 105          | 75         | 30               | dodge omni                           | USA    | 2230          | 252482400000 | 
| 17           | 4         | 120          | 75         | 31               | mazda 626                            | Japan  | 2542          | 315554400000 | 
| 15           | 4         | 108          | 75         | 32               | toyota corolla                       | Japan  | 2265          | 315554400000 | 
| 14           | 4         | 107          | 75         | 33               | honda prelude                        | Japan  | 2210          | 378712800000 | 
| 16           | 4         | 108          | 75         | 32               | toyota corolla                       | Japan  | 2350          | 378712800000 | 
| 14           | 4         | 107          | 75         | 36               | honda Accelerationord                | Japan  | 2205          | 378712800000 | 
| 14           | 4         | 105          | 74         | 33               | volkswagen jetta                     | Europe | 2190          | 378712800000 | 
| 18           | 4         | 120          | 74         | 31               | mazda 626                            | Japan  | 2635          | 378712800000 | 
| 15           | 4         | 105          | 74         | 36               | volkswagen rabbit l                  | Europe | 1980          | 378712800000 | 
| 19           | 4         | 140          | 72         | 22               | chevrolet vega (sw)                  | USA    | 2408          | 31557600000  | 
| 19           | 4         | 140          | 72         | 21               | chevrolet vega                       | USA    | 2401          | 94716000000  | 
| 21           | 6         | 250          | 72         | 15               | mercury monarch                      | USA    | 3432          | 157788000000 | 
| 19           | 6         | 250          | 72         | 15               | ford maverick                        | USA    | 3158          | 157788000000 | 
| 13           | 4         | 140          | 72         | 26               | ford pinto                           | USA    | 2565          | 189324000000 | 
| 17           | 4         | 107          | 72         | 32               | honda Accelerationord                | Japan  | 2290          | 315554400000 | 
| 16           | 4         | 90           | 71         | 25               | volkswagen dasher                    | Europe | 2223          | 157788000000 | 
| 12           | 4         | 97           | 71         | 29               | volkswagen rabbit                    | Europe | 1825          | 189324000000 | 
| 14           | 4         | 89           | 71         | 31               | volkswagen scirocco                  | Europe | 1990          | 252482400000 | 
| 14           | 4         | 89           | 71         | 31               | vw rabbit custom                     | Europe | 1925          | 284018400000 | 
| 24           | 4         | 141          | 71         | 27               | peugeot 504                          | Europe | 3190          | 284018400000 | 
| 19           | 4         | 79           | 70         | 30               | peugeot 304                          | Europe | 2074          | 31557600000  | 
| 20           | 4         | 91           | 70         | 26               | plymouth cricket                     | USA    | 1955          | 31557600000  | 
| 14           | 4         | 90           | 70         | 29               | volkswagen rabbit                    | Europe | 1937          | 157788000000 | 
| 14           | 4         | 90           | 70         | 29               | vw rabbit                            | Europe | 1937          | 189324000000 | 
| 17           | 4         | 85           | 70         | 32               | datsun b-210                         | Japan  | 1990          | 189324000000 | 
| 16           | 4         | 85           | 70         | 33               | datsun f-10 hatchback                | Japan  | 1945          | 220946400000 | 
| 18           | 4         | 85           | 70         | 39               | datsun b210 gx                       | Japan  | 2070          | 252482400000 | 
| 13           | 4         | 105          | 70         | 34               | plymouth horizon                     | USA    | 2200          | 284018400000 | 
| 14           | 4         | 105          | 70         | 34               | plymouth horizon tc3                 | USA    | 2150          | 284018400000 | 
| 15           | 4         | 98           | 70         | 32               | chevrolet chevette                   | USA    | 2120          | 315554400000 | 
| 17           | 4         | 98           | 70         | 36               | mercury lynx l                       | USA    | 2125          | 378712800000 | 
| 16           | 4         | 108          | 70         | 34               | toyota corolla                       | Japan  | 2245          | 378712800000 | 
| 18           | 4         | 72           | 69         | 35               | datsun 1200                          | Japan  | 1613          | 31557600000  | 
| 18           | 4         | 96           | 69         | 26               | renault 12 (sw)                      | Europe | 2189          | 63093600000  | 
| 14           | 4         | 91           | 69         | 37               | fiat strada custom                   | Europe | 2130          | 284018400000 | 
| 18           | 4         | 98           | 68         | 31               | honda Accelerationord cvcc           | Japan  | 2045          | 220946400000 | 
| 16           | 4         | 98           | 68         | 30               | chevrolet chevette                   | USA    | 2155          | 252482400000 | 
| 16           | 4         | 98           | 68         | 29               | honda Accelerationord lx             | Japan  | 2135          | 252482400000 | 
| 16           | 4         | 91           | 68         | 34               | mazda glc 4                          | Japan  | 1985          | 378712800000 | 
| 18           | 4         | 91           | 68         | 37               | mazda glc custom l                   | Japan  | 2025          | 378712800000 | 
| 17           | 4         | 91           | 68         | 31               | mazda glc custom                     | Japan  | 1970          | 378712800000 | 
| 19           | 4         | 79           | 67         | 31               | datsun b210                          | Japan  | 1950          | 126252000000 | 
| 15           | 4         | 79           | 67         | 26               | volkswagen dasher                    | Europe | 1963          | 126252000000 | 
| 16           | 4         | 79           | 67         | 31               | fiat x1.9                            | Europe | 2000          | 126252000000 | 
| 16           | 4         | 97           | 67         | 30               | subaru dl                            | Japan  | 1985          | 220946400000 | 
| 19           | 5         | 121          | 67         | 36               | audi 5000s (diesel)                  | Europe | 2950          | 315554400000 | 
| 21           | 4         | 146          | 67         | 30               | mercedes-benz 240d                   | Europe | 3250          | 315554400000 | 
| 13           | 4         | 91           | 67         | 44               | honda civic 1500 gl                  | Japan  | 1850          | 315554400000 | 
| 18           | 4         | 97           | 67         | 33               | subaru dl                            | Japan  | 2145          | 315554400000 | 
| 17           | 4         | 97           | 67         | 32               | subaru                               | Japan  | 2065          | 378712800000 | 
| 15           | 4         | 91           | 67         | 38               | honda civic                          | Japan  | 1965          | 378712800000 | 
| 15           | 4         | 91           | 67         | 32               | honda civic (auto)                   | Japan  | 1965          | 378712800000 | 
| 16           | 4         | 91           | 67         | 38               | datsun 310 gx                        | Japan  | 1995          | 378712800000 | 
| 14           | 4         | 98           | 66         | 36               | ford fiesta                          | USA    | 1800          | 252482400000 | 
| 19           | 4         | 71           | 65         | 31               | toyota corolla 1200                  | Japan  | 1773          | 31557600000  | 
| 21           | 4         | 71           | 65         | 32               | toyota corolla 1200                  | Japan  | 1836          | 126252000000 | 
| 15           | 4         | 86           | 65         | 34               | maxda glc deluxe                     | Japan  | 1975          | 284018400000 | 
| 19           | 4         | 85           | 65         | 31               | datsun 210                           | Japan  | 2020          | 284018400000 | 
| 16           | 4         | 86           | 65         | 37               | datsun 310                           | Japan  | 2019          | 315554400000 | 
| 17           | 4         | 86           | 65         | 46               | mazda glc                            | Japan  | 2110          | 315554400000 | 
| 19           | 4         | 85           | 65         | 40               | datsun 210                           | Japan  | 2110          | 315554400000 | 
| 19           | 4         | 85           | 65         | 37               | datsun 210                           | Japan  | 1975          | 378712800000 | 
| 16           | 4         | 98           | 65         | 34               | ford escort 4w                       | USA    | 2045          | 378712800000 | 
| 20           | 4         | 98           | 65         | 29               | ford escort 2h                       | USA    | 2380          | 378712800000 | 
| 16           | 4         | 86           | 64         | 39               | plymouth champ                       | USA    | 1875          | 378712800000 | 
| 17           | 4         | 98           | 63         | 30               | chevrolet chevette                   | USA    | 2051          | 220946400000 | 
| 14           | 4         | 105          | 63         | 34               | plymouth horizon 4                   | USA    | 2215          | 378712800000 | 
| 14           | 4         | 105          | 63         | 38               | plymouth horizon miser               | USA    | 2125          | 378712800000 | 
| 15           | 4         | 89           | 62         | 29               | vokswagen rabbit                     | Europe | 1845          | 315554400000 | 
| 17           | 4         | 89           | 62         | 37               | toyota tercel                        | Japan  | 2050          | 378712800000 | 
| 19           | 4         | 83           | 61         | 32               | datsun 710                           | Japan  | 2003          | 126252000000 | 
| 19           | 4         | 97           | 60         | 27               | volkswagen model 111                 | Europe | 1834          | 31557600000  | 
| 22           | 4         | 98           | 60         | 24               | chevrolet woody                      | USA    | 2164          | 189324000000 | 
| 16           | 4         | 91           | 60         | 36               | honda civic cvcc                     | Japan  | 1800          | 252482400000 | 
| 18           | 4         | 89           | 60         | 38               | toyota corolla tercel                | Japan  | 1968          | 315554400000 | 
| 16           | 4         | 81           | 60         | 35               | honda civic 1300                     | Japan  | 1760          | 378712800000 | 
| 18           | 4         | 79           | 58         | 36               | renault 5 gtl                        | Europe | 1825          | 220946400000 | 
| 16           | 4         | 79           | 58         | 39               | toyota starlet                       | Japan  | 1755          | 378712800000 | 
| 23           | 4         | 97           | 54         | 23               | volkswagen type 3                    | Europe | 2254          | 63093600000  | 
| 17           | 4         | 91           | 53         | 33               | honda civic cvcc                     | Japan  | 1795          | 157788000000 | 
| 17           | 4         | 91           | 53         | 33               | honda civic                          | Japan  | 1795          | 189324000000 | 
| 16           | 4         | 76           | 52         | 31               | toyota corona                        | Japan  | 1649          | 126252000000 | 
| 22           | 4         | 85           | 52         | 29               | chevrolet chevette                   | USA    | 2035          | 189324000000 | 
| 19           | 4         | 78           | 52         | 32               | mazda glc deluxe                     | Japan  | 1985          | 252482400000 | 
| 24           | 4         | 97           | 52         | 44               | vw pickup                            | Europe | 2130          | 378712800000 | 
| 19           | 4         | 68           | 49         | 29               | fiat 128                             | Europe | 1867          | 94716000000  | 
| 20           | 4         | 97           | 48         |                  | volkswagen super beetle 117          | Europe | 1978          | 31557600000  | 
| 21           | 4         | 90           | 48         | 43               | volkswagen rabbit custom diesel      | Europe | 1985          | 252482400000 | 
| 21           | 4         | 90           | 48         | 44               | vw rabbit c (diesel)                 | Europe | 2085          | 315554400000 | 
| 23           | 4         | 90           | 48         | 43               | vw dasher (diesel)                   | Europe | 2335          | 315554400000 | 
| 20           | 4         | 97           | 46         | 26               | volkswagen 1131 deluxe sedan         | Europe | 1835          | 21600000     | 
| 21           | 4         | 97           | 46         | 26               | volkswagen super beetle              | Europe | 1950          | 94716000000  | 
| 19           | 4         | 98           |            | 25               | ford pinto                           | USA    | 2046          | 31557600000  | 
| 17           | 6         | 200          |            | 21               | ford maverick                        | USA    | 2875          | 126252000000 | 
| 17           | 4         | 85           |            | 40               | renault lecar deluxe                 | Europe | 1835          | 315554400000 | 
| 14           | 4         | 140          |            | 23               | ford mustang cobra                   | USA    | 2905          | 315554400000 | 
| 15           | 4         | 100          |            | 34               | renault 18i                          | Europe | 2320          | 378712800000 | 
| 20           | 4         | 151          |            | 23               | amc concord dl                       | USA    | 3035          | 378712800000 | 
