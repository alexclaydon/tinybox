Excel formats max columns and row limits:

| Format                                  | Last Cell  | Max Cols | Max Rows | 
|-----------------------------------------|------------|----------|----------| 
| Excel 5.0/95 (XLS BIFF5)                | IV16384    | 256      | 16384    | 
| Excel 2.0/2.1 (XLS BIFF2)               | IV16384    | 256      | 16384    | 
| Excel 97-2004 (XLS BIFF8)               | IV65536    | 256      | 65536    | 
| Excel 2007+ XML Formats (XLSX/XLSM)     | XFD1048576 | 16384    | 1048576  | 
| Excel 2007+ Binary Format (XLSB BIFF12) | XFD1048576 | 16384    | 1048576  | 
