| JS Name       | Excel Description              | 
|---------------|--------------------------------| 
| `Author`      | Summary tab "Author"           | 
| `Category`    | Summary tab "Category"         | 
| `Comments`    | Summary tab "Comments"         | 
| `Company`     | Summary tab "Company"          | 
| `CreatedDate` | Statistics tab "Created"       | 
| `Keywords`    | Summary tab "Keywords"         | 
| `LastAuthor`  | Statistics tab "Last saved by" | 
| `Manager`     | Summary tab "Manager"          | 
| `Subject`     | Summary tab "Subject"          | 
| `Title`       | Summary tab "Title"            | 
